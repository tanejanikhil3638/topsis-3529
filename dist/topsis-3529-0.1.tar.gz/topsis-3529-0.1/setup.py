from setuptools import setup, find_packages

setup(
    name='topsis-3529',
    version='0.1',
    packages=find_packages(),
    install_requires=[
        'numpy>=1.25.1',
        'pandas>=2.0.3'
    ]
)